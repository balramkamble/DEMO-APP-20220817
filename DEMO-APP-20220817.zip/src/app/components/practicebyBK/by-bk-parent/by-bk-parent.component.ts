import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-by-bk-parent',
  templateUrl: './by-bk-parent.component.html',
  styleUrls: ['./by-bk-parent.component.css']
})
export class ByBKParentComponent implements OnInit {

emp:any[];
  constructor() {
   
    this.emp = [
      {title:'Mr', name:'Baliram', email: 'baliram.kamble@capgemini.com', mobile: '9766909796', gender:'M', contacted: true}
    ]
   }

 

  ngOnInit(): void {
  }

}
