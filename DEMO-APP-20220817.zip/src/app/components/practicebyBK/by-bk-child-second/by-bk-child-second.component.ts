import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-by-bk-child-second',
  templateUrl: './by-bk-child-second.component.html',
  styleUrls: ['./by-bk-child-second.component.css']
})
export class ByBKChildSecondComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
