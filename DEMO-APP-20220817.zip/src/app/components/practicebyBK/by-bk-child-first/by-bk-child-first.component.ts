import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-by-bk-child-first',
  templateUrl: './by-bk-child-first.component.html',
  styleUrls: ['./by-bk-child-first.component.css']
})
export class ByBKChildFirstComponent implements OnInit {


  @Input() title:string
  @Input() name:string;
  @Input() email:string;
  @Input() mobile:string;
  @Input() gender:string;
  @Input() contacted:boolean;

  fColors:string;

  constructor() { 
    this.title="";
    this.name="";
    this.email="";
    this.mobile="";
    this.gender="";
    this.contacted= false;

    this.fColors= '';
  }

  ngOnInit(): void {

    this.title = this.gender=='M'? 'Mr.' : 'Mrs.';
    this.fColors = this.gender=='M'? 'text-success' : 'text-danger';
    this.fColors = ! this.contacted== true? 'text-success text-decoration-line-through' : 'text-danger text-decoration-one';
  }

  chkStatus(){
    this.contacted= !this.contacted;
    this.fColors = ! this.contacted== true? 'text-success text-decoration-line-through' : 'text-danger text-decoration-one';
  }

  

}
