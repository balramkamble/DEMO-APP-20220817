export interface Employee{
    name: string;
    age: number;
    designation?: string;
    salary:number;
}