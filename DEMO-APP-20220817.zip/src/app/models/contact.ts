export interface Contact {
    name: string;
    email: string;
    mobile: string; 
    gender: string;
    contacted: boolean;
}